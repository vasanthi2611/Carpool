package com.example.myapplication;

public class RiderHistory {
    private String Owner_name,request_date,request_time,request_status,request_cancel_reason;

    public RiderHistory() {
    }

    public String getOwner_name() {
        return Owner_name;
    }

    public void setOwner_name(String owner_name) {
        Owner_name = owner_name;
    }

    public String getRequest_date() {
        return request_date;
    }

    public void setRequest_date(String request_date) {
        this.request_date = request_date;
    }

    public String getRequest_time() {
        return request_time;
    }

    public void setRequest_time(String request_time) {
        this.request_time = request_time;
    }

    public String getRequest_status() {
        return request_status;
    }

    public void setRequest_status(String request_status) {
        this.request_status = request_status;
    }

    public String getRequest_cancel_reason() {
        return request_cancel_reason;
    }

    public void setRequest_cancel_reason(String request_cancel_reason) {
        this.request_cancel_reason = request_cancel_reason;
    }
}
