package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    private final List<MyItems> items;
    private final Context context;

    public MyAdapter(List<MyItems> items, Context context) {
        this.items = items;
        this.context = context;
    }

    @NonNull
    @Override
    public MyAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_adapter_layout,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.MyViewHolder holder, int position) {
        MyItems myItems=items.get(position);
        holder.name.setText(myItems.getName());
        holder.phonenum.setText(myItems.getPhonenumber());
        holder.startloc.setText(myItems.getStartloc());
        holder.route.setText(myItems.getRoute());
        holder.seats.setText(myItems.getSeatsavailable());
        holder.carnum.setText(myItems.getCarnum());
        holder.traveldate.setText(myItems.getTraveldate());
        holder.emailid.setText(myItems.getEmailid());
        holder.requestbn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               Intent homeINTENT = new Intent(context, MainActivity2.class);
             homeINTENT.putExtra("name",myItems.getName());
                 homeINTENT.putExtra("phonenum",myItems.getPhonenumber());
               homeINTENT.putExtra("startloc",myItems.getStartloc());
                homeINTENT.putExtra("route",myItems.getRoute());
                 homeINTENT.putExtra("seats",myItems.getSeatsavailable());
                 homeINTENT.putExtra("carnum",myItems.getCarnum());
                 homeINTENT.putExtra("starttime",myItems.getStarttime());
                homeINTENT.putExtra("emailid",myItems.getEmailid());
                context.startActivity(homeINTENT);

            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class MyViewHolder extends RecyclerView.ViewHolder{
        private final TextView name,phonenum,startloc,route,seats,carnum,starttime,emailid,traveldate;
       private final TextView requestbn;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.nameadap);
            phonenum=itemView.findViewById(R.id.phoneadap);
            startloc=itemView.findViewById(R.id.startlocadap);
            route=itemView.findViewById(R.id.routeadap);
            seats=itemView.findViewById(R.id.seatsavailadap);
            carnum=itemView.findViewById(R.id.carnumap);
            starttime=itemView.findViewById(R.id.starttimeap);
            requestbn=itemView.findViewById(R.id.requestid);
            emailid=itemView.findViewById(R.id.emailidap);
            traveldate=itemView.findViewById(R.id.traveldate_data);

        }
    }
}
