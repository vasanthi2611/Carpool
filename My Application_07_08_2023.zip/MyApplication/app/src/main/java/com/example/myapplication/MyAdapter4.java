package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class MyAdapter4 extends RecyclerView.Adapter<MyAdapter4.MyViewHolder4> {
    private final List<MyItems4> items4;
    private final Context context;


    public MyAdapter4(List<MyItems4> items4, Context context) {
        this.items4 = items4;
        this.context = context;
    }

    @NonNull
    @Override
    public MyAdapter4.MyViewHolder4 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder4(LayoutInflater.from(parent.getContext()).inflate(R.layout.ride_offere_history_adapter_recycle,null));
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter4.MyViewHolder4 holder, int position) {
        MyItems4 myItems4=items4.get(position);
        holder.name.setText(myItems4.getName4());

        holder.date.setText(myItems4.getDate4());
        holder.time.setText(myItems4.getTime4());

        holder.reqstatus.setText(myItems4.getReqstatus4());
        holder.ridecancelreason.setText(myItems4.getReqcanreason4());
        String Check_status = myItems4.getReqstatus4();

        if(Check_status.equals("Accepted"))
        {
            holder.ridecancelreason.setVisibility(View.INVISIBLE);
        }



    }
    @Override
    public int getItemCount() {
        return items4.size();
    }

    static class MyViewHolder4 extends RecyclerView.ViewHolder{
        private final TextView name,reqstatus,ridecancelreason,date,time;


        public MyViewHolder4(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.reqstatusname_offer_hist);

            reqstatus=itemView.findViewById(R.id.ridestat_offer_hist);

            ridecancelreason=itemView.findViewById(R.id.ride_can_reason_data_offer_hist);
            date=itemView.findViewById(R.id.dateadapr_rideoffer_hist);
            time=itemView.findViewById(R.id.timeadap_rideoffer_hist);


        }
    }
}
