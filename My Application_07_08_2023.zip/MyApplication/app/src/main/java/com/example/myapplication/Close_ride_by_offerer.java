package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class Close_ride_by_offerer extends AppCompatActivity {
    private TextView name,phonenum,date,time,reqstatus,ridecancelreason_owner,textmsg_close;




    private String Sreqname,Sreqphone,request_date,request_time,request_status,req_cancel_reason;


    public long maxid=0;
    public String Maxid="1";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_close_ride_by_offerer);
        name = findViewById(R.id.close_name_offer);
        phonenum = findViewById(R.id.close_phone_offer);
        date = findViewById(R.id.close_date_offer);
        time = findViewById(R.id.close_time_offer);
        reqstatus = findViewById(R.id.close_status_offer);
        ridecancelreason_owner = findViewById(R.id.close_reason_offer);
        textmsg_close=findViewById(R.id.textmsg_close);
        name.setText(getIntent().getStringExtra("name"));
        phonenum.setText(getIntent().getStringExtra("phonenum"));
        date.setText(getIntent().getStringExtra("date"));
        time.setText(getIntent().getStringExtra("time"));
        reqstatus.setText(getIntent().getStringExtra("reqstatus"));
        ridecancelreason_owner.setText(getIntent().getStringExtra("ridecancelreason_owner"));
        Sreqname= name.getText().toString().trim();
        Sreqphone= phonenum.getText().toString().trim();
        request_date= date.getText().toString().trim();
        request_time= time.getText().toString().trim();
        request_status= reqstatus.getText().toString().trim();
        req_cancel_reason= ridecancelreason_owner.getText().toString().trim();
        System.out.println("inside CLOE RIDE PAGE BY OFFERE");
        System.out.println("request_status"+request_status);
        System.out.println("req_cancel_reason"+req_cancel_reason);
        get_child_num();


    }













            public void get_child_num()
            {
                final DatabaseReference reference3 = FirebaseDatabase.getInstance("https://car-pool-ride-given-history.firebaseio.com/").getReference().child(GlobalVariable.login_phone);
                reference3.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists())
                        {
                            maxid=(snapshot.getChildrenCount());
                            System.out.println("maxid_P1:"+maxid);
                            maxid=maxid+1;
                            System.out.println("maxid_P2:"+maxid);
                            Maxid=Long.toString(maxid);
                        }

                        CarpoolerHistory  carpoolerHistory=new CarpoolerHistory();
                        carpoolerHistory.setRequestor_name(Sreqname);
                        carpoolerHistory.setRequest_date(request_date);
                        carpoolerHistory.setRequest_cancel_reason(req_cancel_reason);
                        carpoolerHistory.setRequest_status(request_status);
                        carpoolerHistory.setRequest_time(request_time);

                        System.out.println("maxid_1:"+maxid);

                        System.out.println("maxid_2:"+Maxid);

                        final DatabaseReference reference4 = FirebaseDatabase.getInstance("https://car-pool-ride-given-history.firebaseio.com/").getReference().child(GlobalVariable.login_phone);

                        reference4.child(Maxid).setValue(carpoolerHistory);
                        delete_active_rides_table();

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }


            public void delete_active_rides_table()
            {
                final DatabaseReference reference2 = FirebaseDatabase.getInstance("https://activerides-72ed2.firebaseio.com/").getReference().child(GlobalVariable.login_phone).child(Sreqphone);
                reference2.child("name").setValue(null);
                reference2.child("Phonenum").setValue(null);
                reference2.child("status").setValue(null);
                reference2.child("reason").setValue(null);
                reference2.child("request date").setValue(null);
                reference2.child("request time").setValue(null);
                reference2.child("boarding point").setValue(null);
                reference2.child("requestor email").setValue(null);
                reference2.child("boarding time").setValue(null)

                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                textmsg_close.setText("This ride request is closed");

                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                            }
                        });
            }


}