package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

////this class is to cancel ride request by car owner and write status into active ride table and accept/reject table.
public class AcceptReject1 extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private TextView name,phonenum,ride_cancel_msg_owner,date,time,reqemailid;

    private Button ride_can_reason_sub_owner;

    private EditText update_seats;
    private String Sreqname,Sreason,Sreqphone,request_date,request_time,num_of_seats,Requestor_email_id;

    private int intLayout=1;
    public long maxid=0;
    public String Maxid="1";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accept_reject1);
        System.out.println("inside accept rej1");
        reqemailid = findViewById(R.id.requestor_email_acceptrej1);
        name = findViewById(R.id.name41);
        phonenum = findViewById(R.id.phone41);
        date = findViewById(R.id.can_date_req_pooler);
        time = findViewById(R.id.can_time_req_pooler);
        name.setText(getIntent().getStringExtra("name"));
        phonenum.setText(getIntent().getStringExtra("phonenum"));
        date.setText(getIntent().getStringExtra("date"));
        time.setText(getIntent().getStringExtra("time"));
        reqemailid.setText(getIntent().getStringExtra("reqemailid"));
        ride_cancel_msg_owner=findViewById(R.id.ride_can_msg_owner);
        Sreqname= name.getText().toString().trim();
        Sreqphone= phonenum.getText().toString().trim();
        request_date= date.getText().toString().trim();
        request_time= time.getText().toString().trim();
        Requestor_email_id = reqemailid.getText().toString().trim();
        Spinner spinner=findViewById(R.id.can_reason_spinner_id_owner);
        ArrayAdapter<CharSequence> adapter= ArrayAdapter.createFromResource(this,R.array.Cancelreasonsowner,android.R.layout.simple_list_item_1);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);


    }


    public void updatenumseats(){
        int intLayout=2;
        setContentView(R.layout.update_num_seats);

        Button Update_seats=(Button) findViewById(R.id.updatenum_seats);
        Update_seats.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                update_seats = (EditText) findViewById(R.id.numseatsdata);
                final String update_tab_seats = update_seats.getText().toString().trim();

                final DatabaseReference reference3 = FirebaseDatabase.getInstance("https://ridedetailsdb.firebaseio.com/").getReference().child(GlobalVariable.login_phone);
                reference3.child("maximum seats").setValue(update_tab_seats);
                reference3.child("seats available").setValue(update_tab_seats)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(AcceptReject1.this,"No of seats updated",Toast.LENGTH_SHORT)  .show();



                            }


                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                            }
                        });
            }
        });

    }
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        Sreason= adapterView.getItemAtPosition(i).toString();


        ride_can_reason_sub_owner=findViewById(R.id.ride_can_submit_owner);

        ride_can_reason_sub_owner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                check_requestor_table();



        }


            public void check_requestor_table(){

                final DatabaseReference reference1 = FirebaseDatabase.getInstance("https://car-pool-accept-reject-pending.firebaseio.com/").getReference().child(Sreqphone).child(GlobalVariable.login_phone);


                reference1.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists())
                        {
                            get_child_num();

                        }
                        else{
                            ride_cancel_msg_owner.setText("This ride is closed already by Requestor.Please close this ride!!");
                            ride_cancel_msg_owner.setVisibility(View.VISIBLE);
                            ride_cancel_msg_owner.setTextColor(Color.BLACK);
                            ride_cancel_msg_owner.postDelayed(new Runnable() {
                                @Override
                                public void run() {
                                    ride_cancel_msg_owner.setVisibility(View.INVISIBLE);
                                }
                            },10000);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


            }
            public void get_child_num()
            {
                final DatabaseReference reference3 = FirebaseDatabase.getInstance("https://car-pool-ride-given-history.firebaseio.com/").getReference().child(GlobalVariable.login_phone);
                reference3.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.exists())
                        {
                            maxid=(snapshot.getChildrenCount());
                            System.out.println("maxid_P1:"+maxid);
                            maxid=maxid+1;
                            System.out.println("maxid_P2:"+maxid);
                            Maxid=Long.toString(maxid);
                        }

                        CarpoolerHistory  carpoolerHistory=new CarpoolerHistory();
                        carpoolerHistory.setRequestor_name(Sreqname);
                        carpoolerHistory.setRequest_date(request_date);
                        carpoolerHistory.setRequest_cancel_reason(Sreason);
                        carpoolerHistory.setRequest_status("Cancelled by you");
                        carpoolerHistory.setRequest_time(request_time);

                        System.out.println("maxid_1:"+maxid);

                        System.out.println("maxid_2:"+Maxid);

                        final DatabaseReference reference4 = FirebaseDatabase.getInstance("https://car-pool-ride-given-history.firebaseio.com/").getReference().child(GlobalVariable.login_phone);

                        reference4.child(Maxid).setValue(carpoolerHistory);
                        delete_active_rides_table();

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }


            public void delete_active_rides_table()
            {
                final DatabaseReference reference2 = FirebaseDatabase.getInstance("https://activerides-72ed2.firebaseio.com/").getReference().child(GlobalVariable.login_phone).child(Sreqphone);
                reference2.child("name").setValue(null);
                reference2.child("Phonenum").setValue(null);
                reference2.child("status").setValue(null);
                reference2.child("reason").setValue(null);
                reference2.child("request date").setValue(null);
                reference2.child("request time").setValue(null);
                reference2.child("boarding point").setValue(null);
                reference2.child("requestor email").setValue(null);
                reference2.child("boarding time").setValue(null)

                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                update_requestor_table();

                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                            }
                        });
            }


       public void  update_requestor_table(){
           final DatabaseReference reference3 = FirebaseDatabase.getInstance("https://car-pool-accept-reject-pending.firebaseio.com/").getReference().child(Sreqphone).child(GlobalVariable.login_phone);

           reference3.child("request_status").setValue("Cancelled by carpooler");
           reference3.child("reason").setValue(Sreason)
                   .addOnSuccessListener(new OnSuccessListener<Void>() {
                       @Override
                       public void onSuccess(Void unused) {

                           send_email_to_requestor();
                           ride_cancel_msg_owner.setText("Your have cancelled carpool request!!");
                           ride_cancel_msg_owner.setVisibility(View.VISIBLE);
                           ride_cancel_msg_owner.setTextColor(Color.BLACK);
                           ride_cancel_msg_owner.postDelayed(new Runnable() {
                               @Override
                               public void run() {
                                   ride_cancel_msg_owner.setVisibility(View.INVISIBLE);
                               }
                           }, 1000);




                           new AlertDialog.Builder(AcceptReject1.this)
                                   .setMessage("Do you want to update no of available seats?")
                                   .setCancelable(false)
                                   .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                       @Override
                                       public void onClick(DialogInterface dialogInterface, int i) {
                                           updatenumseats();
                                       }
                                   })
                                   .setNegativeButton("No", null)
                                   .show();

                       }
                   })
                   .addOnFailureListener(new OnFailureListener() {
                       @Override
                       public void onFailure(@NonNull Exception e) {

                       }
                   });

       }

    });



}

    public void send_email_to_requestor(){

        try {
            String stringSenderEmail = "fiscarpool210623@gmail.com";
            String stringReceiverEmail = Requestor_email_id;
            String stringPasswordSenderEmail = "foaunfwnqmabwibh";

            String stringHost = "smtp.gmail.com";

            Properties properties = System.getProperties();

            properties.put("mail.smtp.host", stringHost);
            properties.put("mail.smtp.port", "465");
            properties.put("mail.smtp.ssl.enable", "true");
            properties.put("mail.smtp.auth", "true");

            javax.mail.Session session = Session.getInstance(properties, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(stringSenderEmail, stringPasswordSenderEmail);
                }
            });

            MimeMessage mimeMessage = new MimeMessage(session);
            mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(stringReceiverEmail));

            mimeMessage.setSubject("Subject: FIS Carpool App email");
            mimeMessage.setText(GlobalVariable.login_name+" Declined your request with below reason \n\n"+Sreason);

            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Transport.send(mimeMessage);
                    } catch (MessagingException e) {
                        e.printStackTrace();
                    }
                }
            });
            thread.start();

        } catch (AddressException e) {
            e.printStackTrace();
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}