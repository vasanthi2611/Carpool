package com.example.myapplication;

public class MyItems1 {
    private String name,phonenumber,Reqphonenumber,reqstatus,reqcancel,reqdate,reqtime,reqboardingpoint,reqemailid,reqboardingtime;

    public MyItems1(String name, String phonenumber,String reqstatus,String reqcancel,String reqdate,String reqtime,String reqboardingpoint,String reqboardingtime,String reqemailid) {
        this.name = name;
        this.phonenumber = phonenumber;
        this.reqstatus = reqstatus;
        this.reqcancel = reqcancel;
        this.reqdate = reqdate;
        this.reqtime = reqtime;
        this.reqboardingpoint = reqboardingpoint;
        this.reqboardingtime = reqboardingtime;
        this.reqemailid = reqemailid;
        Reqphonenumber=phonenumber;

        System.out.println("Test: Inside Myitem1 to assign data to variable");

    }

    public String getName1() {
        return name;
    }

    public String getPhonenumber1() {
        return phonenumber;
    }

    public String getRequeststatus1() {
        return reqstatus;
    }

    public String getReqcancel1() {
        return reqcancel;
    }

    public String getDate1() {
        return reqdate;
    }

    public String getTime1() {
        return reqtime;
    }

    public String getBoardingpoint1() {
        return reqboardingpoint;
    }

    public String getBoardingtime1() {
        return reqboardingtime;
    }

    public String getReqemailid1() {
        return reqemailid;
    }

}
