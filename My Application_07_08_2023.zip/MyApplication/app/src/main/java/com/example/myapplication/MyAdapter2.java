package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class MyAdapter2 extends RecyclerView.Adapter<MyAdapter2.MyViewHolder2> {
    private final List<MyItems2> items2;
    private final Context context;


    public MyAdapter2(List<MyItems2> items2, Context context) {
        this.items2 = items2;
        this.context = context;
    }

    @NonNull
    @Override
    public MyAdapter2.MyViewHolder2 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder2(LayoutInflater.from(parent.getContext()).inflate(R.layout.riderequest_status_recycle,null));
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter2.MyViewHolder2 holder, int position) {
        MyItems2 myItems2=items2.get(position);
        holder.name.setText(myItems2.getName2());
        holder.phonenum.setText(myItems2.getPhonenumber2());
        holder.date.setText(myItems2.getDate2());
        holder.time.setText(myItems2.getTime2());

        holder.reqstatus.setText(myItems2.getReqstatus2());
        holder.ridecancelreason.setText(myItems2.getReqcanreason2());
        holder.carpooleremailid.setText(myItems2.getCarpooleremail2());

        String Check_status = myItems2.getReqstatus2();

        if(Check_status.equals("Request Pending"))
        {
            holder.ridecancel.setEnabled(true);
            holder.rideclose.setEnabled(false);
            holder.ridecancelreason.setVisibility(View.INVISIBLE);
            holder.ridecancel.setVisibility(View.VISIBLE);
            holder.rideclose.setVisibility(View.INVISIBLE);
        }
        else {
            if(Check_status.equals("Accepted"))
            {
                holder.ridecancel.setEnabled(true);
                holder.rideclose.setEnabled(true);
                holder.ridecancelreason.setVisibility(View.INVISIBLE);
                holder.ridecancel.setVisibility(View.VISIBLE);
                holder.rideclose.setVisibility(View.VISIBLE);
            }
            else {
                if(Check_status.equals("Cancelled by carpooler"))
                {
                    holder.ridecancel.setEnabled(false);
                    holder.rideclose.setEnabled(true);
                    holder.ridecancelreason.setVisibility(View.VISIBLE);
                    holder.ridecancel.setVisibility(View.INVISIBLE);
                    holder.rideclose.setVisibility(View.VISIBLE);
                }
            }
        }


        holder.ridecancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("Inside Adapter1. Request clicked");
                Intent homeINTENT = new Intent(context, Cancel_Ride_request_by_rider.class);
                homeINTENT.putExtra("name",myItems2.getName2());
                homeINTENT.putExtra("phonenum",myItems2.getPhonenumber2());
                homeINTENT.putExtra("date",myItems2.getDate2());
                homeINTENT.putExtra("time",myItems2.getTime2());
                homeINTENT.putExtra("reqstatus",myItems2.getReqstatus2());
                homeINTENT.putExtra("carpooleremailid",myItems2.getCarpooleremail2());

                context.startActivity(homeINTENT);

            }

    });


        holder.rideclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("Inside Adapter2. close clicked");
                Intent homeINTENT = new Intent(context, Close_ride_by_ride_requestor.class);
                homeINTENT.putExtra("name",myItems2.getName2());
                homeINTENT.putExtra("phonenum",myItems2.getPhonenumber2());
                homeINTENT.putExtra("date",myItems2.getDate2());
                homeINTENT.putExtra("time",myItems2.getTime2());
                homeINTENT.putExtra("reqstatus",myItems2.getReqstatus2());
                homeINTENT.putExtra("ridecancelreason",myItems2.getReqcanreason2());

                context.startActivity(homeINTENT);

            }

        });




    }
    @Override
    public int getItemCount() {
        return items2.size();
    }

    static class MyViewHolder2 extends RecyclerView.ViewHolder{
        private final TextView name,phonenum,reqstatus,ridecancelreason,date,time,carpooleremailid;

      private final Button ridecancel,rideclose;
        public MyViewHolder2(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.reqstatusname);
            phonenum=itemView.findViewById(R.id.reqstatusphone);
            reqstatus=itemView.findViewById(R.id.ridestat);
            ridecancel=itemView.findViewById(R.id.ridecan);
            ridecancelreason=itemView.findViewById(R.id.ride_can_reason_data);
            date=itemView.findViewById(R.id.dateadapr_ridereq);
            time=itemView.findViewById(R.id.timeadap_ridereq);
            rideclose=itemView.findViewById(R.id.rideclose);
            carpooleremailid=itemView.findViewById(R.id.car_pooler_email);
        }
    }
}
