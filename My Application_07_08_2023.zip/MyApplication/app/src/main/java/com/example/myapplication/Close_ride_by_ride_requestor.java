package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Close_ride_by_ride_requestor extends AppCompatActivity {
    private TextView name, phonenum,reqstatus,ridecancelreason,date,time;
    private String Owner_Phone,Owner_name,request_date,request_time,request_status,request_cancel_reason;
    public long maxid=0;
    public String Maxid="1";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_close_ride_by_ride_requestor);

        name = findViewById(R.id.close_name);
        phonenum = findViewById(R.id.close_phone);
        reqstatus = findViewById(R.id.close_status);
        ridecancelreason = findViewById(R.id.close_reason);
        date = findViewById(R.id.close_date);
        time = findViewById(R.id.close_time);
        name.setText(getIntent().getStringExtra("name"));
        phonenum.setText(getIntent().getStringExtra("phonenum"));
        date.setText(getIntent().getStringExtra("date"));
        time.setText(getIntent().getStringExtra("time"));
        reqstatus.setText(getIntent().getStringExtra("reqstatus"));
        ridecancelreason.setText(getIntent().getStringExtra("ridecancelreason"));

        Owner_Phone = phonenum.getText().toString().trim();
        Owner_name = name.getText().toString().trim();
        request_date = date.getText().toString().trim();
        request_time = time.getText().toString().trim();
        request_status = reqstatus.getText().toString().trim();
        request_cancel_reason = ridecancelreason.getText().toString().trim();
         String Userphone=GlobalVariable.login_phone;

              get_child_num();





    }



    public void get_child_num()
    {
        final DatabaseReference reference3 = FirebaseDatabase.getInstance("https://car-pool-ride-taken-history.firebaseio.com/").getReference().child(GlobalVariable.login_phone);
        reference3.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists())
                {
                    maxid=(snapshot.getChildrenCount());
                    System.out.println("maxid_P1:"+maxid);
                    maxid=maxid+1;
                    System.out.println("maxid_P2:"+maxid);
                    Maxid=Long.toString(maxid);
                }

                RiderHistory  riderHistory=new RiderHistory();
                riderHistory.setOwner_name(Owner_name);
                riderHistory.setRequest_date(request_date);
                riderHistory.setRequest_cancel_reason(request_cancel_reason);
                riderHistory.setRequest_status(request_status);
                riderHistory.setRequest_time(request_time);

                System.out.println("maxid_1:"+maxid);

                System.out.println("maxid_2:"+Maxid);

                final DatabaseReference reference4 = FirebaseDatabase.getInstance("https://car-pool-ride-taken-history.firebaseio.com/").getReference().child(GlobalVariable.login_phone);

                reference4.child(Maxid).setValue(riderHistory);
                empty_accept_reject_request();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public void empty_accept_reject_request()
    {
        final DatabaseReference reference1=FirebaseDatabase.getInstance("https://car-pool-accept-reject-pending.firebaseio.com/").getReference().child(GlobalVariable.login_phone).child(Owner_Phone);

        reference1.child("car_owner_name").setValue(null);
        reference1.child("car_owner_phonenum").setValue(null);
        reference1.child("request_status").setValue(null);
        reference1.child("reason").setValue(null);
        reference1.child("request date").setValue(null);
        reference1.child("request time").setValue(null);
        reference1.child("boarding point").setValue(null);
        reference1.child("car owner email").setValue(null);
        reference1.child("boarding time").setValue(null)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });

    }
}