package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class MyAdapter3 extends RecyclerView.Adapter<MyAdapter3.MyViewHolder3> {
    private final List<MyItems3> items3;
    private final Context context;


    public MyAdapter3(List<MyItems3> items3, Context context) {
        this.items3 = items3;
        this.context = context;
    }

    @NonNull
    @Override
    public MyAdapter3.MyViewHolder3 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder3(LayoutInflater.from(parent.getContext()).inflate(R.layout.ride_requestor_history_adapter_recycle,null));
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter3.MyViewHolder3 holder, int position) {
        MyItems3 myItems3=items3.get(position);
        holder.name.setText(myItems3.getName3());

        holder.date.setText(myItems3.getDate3());
        holder.time.setText(myItems3.getTime3());

        holder.reqstatus.setText(myItems3.getReqstatus3());
        holder.ridecancelreason.setText(myItems3.getReqcanreason3());








    }
    @Override
    public int getItemCount() {
        return items3.size();
    }

    static class MyViewHolder3 extends RecyclerView.ViewHolder{
        private final TextView name,reqstatus,ridecancelreason,date,time;


        public MyViewHolder3(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.reqstatusname_hist);

            reqstatus=itemView.findViewById(R.id.ridestat_hist);

            ridecancelreason=itemView.findViewById(R.id.ride_can_reason_data_hist);
            date=itemView.findViewById(R.id.dateadapr_ridereq_hist);
            time=itemView.findViewById(R.id.timeadap_ridereq_hist);


        }
    }
}
