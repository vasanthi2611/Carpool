package com.example.myapplication;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class MyAdapter1 extends RecyclerView.Adapter<MyAdapter1.MyViewHolder1> {
    private final List<MyItems1> items1;
    private final Context context;


    public MyAdapter1(List<MyItems1> items1, Context context) {
        this.items1 = items1;
        this.context = context;
    }

    @NonNull
    @Override
    public MyAdapter1.MyViewHolder1 onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyViewHolder1(LayoutInflater.from(parent.getContext()).inflate(R.layout.checkrequest_adapterrecycle,null));
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter1.MyViewHolder1 holder, int position) {
        MyItems1 myItems1=items1.get(position);
        holder.name.setText(myItems1.getName1());
        holder.phonenum.setText(myItems1.getPhonenumber1());
        holder.date.setText(myItems1.getDate1());
        holder.time.setText(myItems1.getTime1());
        holder.reqstatus.setText(myItems1.getRequeststatus1());
        holder.ridecancelreason_owner.setText(myItems1.getReqcancel1());
        holder.reqboardingpoint.setText(myItems1.getBoardingpoint1());
        holder.reqboardingtime.setText(myItems1.getBoardingtime1());
        holder.reqemailid.setText(myItems1.getReqemailid1());
        System.out.println("Test: Inside onBindView holder to get data fro get function to holder variable");
         String Check_status = myItems1.getRequeststatus1();
        String requestor_mail = myItems1.getReqemailid1();
          System.out.println("Code executed for closing ride");

        System.out.println("requestor_mail:"+requestor_mail);
            if(Check_status.equals("Pending"))
            {
                holder.reqaccept.setEnabled(true);
                holder.reqrej.setEnabled(true);
                holder.ridecancelreason_owner.setVisibility(View.INVISIBLE);
                holder.reqaccept.setVisibility(View.VISIBLE);
                holder.reqrej.setVisibility(View.VISIBLE);
                holder.reqclose.setVisibility(View.INVISIBLE);
            }
            else{
                if(Check_status.equals("Accepted"))
                {
                    holder.ridecancelreason_owner.setVisibility(View.INVISIBLE);
                    holder.reqaccept.setEnabled(false);
                    holder.reqaccept.setVisibility(View.INVISIBLE);
                    holder.reqrej.setEnabled(true);
                    holder.reqrej.setVisibility(View.VISIBLE);
                    holder.reqclose.setVisibility(View.VISIBLE);
                }
                else{
                    if(Check_status.equals("Cancelled by requestor"))
                    {
                        holder.ridecancelreason_owner.setVisibility(View.VISIBLE);
                        holder.reqaccept.setEnabled(false);
                        holder.reqaccept.setVisibility(View.INVISIBLE);
                        holder.reqrej.setEnabled(false);
                        holder.reqrej.setVisibility(View.INVISIBLE);
                        holder.reqclose.setVisibility(View.VISIBLE);
                    }
                }
            }
////////////////////below code is for status reason//////////////////


        holder.reqaccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("Inside Adapter1. Request clicked");
                Intent homeINTENT = new Intent(context, AcceptReject.class);
                homeINTENT.putExtra("name",myItems1.getName1());
                homeINTENT.putExtra("phonenum",myItems1.getPhonenumber1());
                homeINTENT.putExtra("reqemailid",myItems1.getReqemailid1());
                System.out.println("inside my adapter");
                context.startActivity(homeINTENT);



            }
        });

        holder.reqrej.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent homeINTENT = new Intent(context, AcceptReject1.class);
                homeINTENT.putExtra("name",myItems1.getName1());
                homeINTENT.putExtra("phonenum",myItems1.getPhonenumber1());
                homeINTENT.putExtra("reqstatus",myItems1.getRequeststatus1());
                homeINTENT.putExtra("date",myItems1.getDate1());
                homeINTENT.putExtra("time",myItems1.getTime1());
                homeINTENT.putExtra("reqemailid",myItems1.getReqemailid1());

                System.out.println("inside my adapter");
                context.startActivity(homeINTENT);


            }
        });
        holder.reqclose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent homeINTENT = new Intent(context, Close_ride_by_offerer.class);
                homeINTENT.putExtra("name",myItems1.getName1());
                homeINTENT.putExtra("phonenum",myItems1.getPhonenumber1());
                homeINTENT.putExtra("reqstatus",myItems1.getRequeststatus1());
                homeINTENT.putExtra("date",myItems1.getDate1());
                homeINTENT.putExtra("time",myItems1.getTime1());
                homeINTENT.putExtra("ridecancelreason_owner",myItems1.getReqcancel1());
                System.out.println("inside my adapter");
                context.startActivity(homeINTENT);


            }
        });

    }

    @Override
    public int getItemCount() {
        return items1.size();
    }

    static class MyViewHolder1 extends RecyclerView.ViewHolder{
        private final TextView name,phonenum,reqstatus,ridecancelreason_owner,date,reqemailid,time,reqboardingpoint,reqboardingtime;
        private final Button reqaccept,reqrej,reqclose;


        public MyViewHolder1(@NonNull View itemView) {


            super(itemView);
            name=itemView.findViewById(R.id.nameadap2);
            phonenum=itemView.findViewById(R.id.phoneadap2);
            reqaccept=itemView.findViewById(R.id.raccept);
            reqrej=itemView.findViewById(R.id.rreject);
            reqstatus=itemView.findViewById(R.id.acceptdeclstatus);
            ridecancelreason_owner=itemView.findViewById(R.id.ride_can_reason_data_owner);
            date=itemView.findViewById(R.id.dateadapr);
            time=itemView.findViewById(R.id.timeadap);
            reqboardingpoint=itemView.findViewById(R.id.rboarding_point_data);
            reqboardingtime=itemView.findViewById(R.id.rboarding_time_data);
            reqclose=itemView.findViewById(R.id.req_close_owner);
            reqemailid=itemView.findViewById(R.id.reqemailid_data);
            System.out.println("Test: Inside myviewholder to get textview ids");
        }
    }
}
