package com.example.myapplication;

public class MyItems3 {
    private String name,reqstatus,reqcanreason,reqdate,reqtime;

    public MyItems3(String name, String reqstatus,String reqcanreason,String reqdate,String reqtime) {
        this.name = name;

        this.reqstatus = reqstatus;
        this.reqdate = reqdate;
        this.reqtime = reqtime;
        this.reqcanreason=reqcanreason;


    }



    public String getName3() {
        return name;
    }



    public String getReqstatus3() {
        return reqstatus;
    }

    public String getReqcanreason3() {
        return reqcanreason;
    }

    public String getDate3() {
        return reqdate;
    }

    public String getTime3() {
        return reqtime;
    }

}
