package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Cancel_Ride_request_by_rider extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    private Button ride_can_reason_sub;
    private TextView name, phonenum,reqstatus,date,time,ride_cancel_msg,carpooleremailid;
    private String Owner_Phone,Owner_name,Sreason,request_date,request_time,request_status,num_of_seats,max_num_of_seats,Carpooler_email_id;
    public long maxid=0;
    public String Maxid="1";
    public int Total_num_seats,Total_max_num_seats;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cancel_ride_request_by_rider);

        name = findViewById(R.id.ridecanname);
        phonenum = findViewById(R.id.ridecanphone);
        reqstatus = findViewById(R.id.close_status_req);

        date = findViewById(R.id.close_date_req);
        time = findViewById(R.id.close_time_req);
        carpooleremailid = findViewById(R.id.carpooler_email_id_cancel);
        name.setText(getIntent().getStringExtra("name"));
        phonenum.setText(getIntent().getStringExtra("phonenum"));
        carpooleremailid.setText(getIntent().getStringExtra("carpooleremailid"));
        date.setText(getIntent().getStringExtra("date"));
        time.setText(getIntent().getStringExtra("time"));
        reqstatus.setText(getIntent().getStringExtra("reqstatus"));
        ride_cancel_msg=findViewById(R.id.ride_can_msg);
        Owner_Phone = phonenum.getText().toString().trim();
        Owner_name = name.getText().toString().trim();
        request_date = date.getText().toString().trim();
        request_time = time.getText().toString().trim();
        request_status = reqstatus.getText().toString().trim();
        Carpooler_email_id = carpooleremailid.getText().toString().trim();

       Spinner spinner=findViewById(R.id.can_reason_spinner_id);
        ArrayAdapter<CharSequence> adapter= ArrayAdapter.createFromResource(this,R.array.Cancelreasons,android.R.layout.simple_list_item_1);
        adapter.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);


    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        Sreason= adapterView.getItemAtPosition(i).toString();

        ride_can_reason_sub=findViewById(R.id.ride_can_submit);
       ride_can_reason_sub.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               check_carpooler_table();

           }
           public void get_child_num()
           {
               final DatabaseReference reference3 = FirebaseDatabase.getInstance("https://car-pool-ride-taken-history.firebaseio.com/").getReference().child(GlobalVariable.login_phone);
               reference3.addListenerForSingleValueEvent(new ValueEventListener() {
                   @Override
                   public void onDataChange(@NonNull DataSnapshot snapshot) {
                       if(snapshot.exists())
                       {
                           maxid=(snapshot.getChildrenCount());
                           System.out.println("maxid_P1:"+maxid);
                           maxid=maxid+1;
                           System.out.println("maxid_P2:"+maxid);
                           Maxid=Long.toString(maxid);
                       }

                       RiderHistory  riderHistory=new RiderHistory();
                       riderHistory.setOwner_name(Owner_name);
                       riderHistory.setRequest_date(request_date);
                       riderHistory.setRequest_cancel_reason(Sreason);
                       riderHistory.setRequest_status("Cancelled by you");
                       riderHistory.setRequest_time(request_time);

                       System.out.println("maxid_1:"+maxid);

                       System.out.println("maxid_2:"+Maxid);

                       final DatabaseReference reference4 = FirebaseDatabase.getInstance("https://car-pool-ride-taken-history.firebaseio.com/").getReference().child(GlobalVariable.login_phone);

                       reference4.child(Maxid).setValue(riderHistory);

                       empty_accept_reject_request();

                   }

                   @Override
                   public void onCancelled(@NonNull DatabaseError error) {

                   }
               });

           }
           public void  empty_accept_reject_request(){
               final DatabaseReference reference1 = FirebaseDatabase.getInstance("https://car-pool-accept-reject-pending.firebaseio.com/").getReference().child(GlobalVariable.login_phone).child(Owner_Phone);

//               reference1.child("request_status").setValue("Cancelled by you");
//               reference1.child("reason").setValue(Sreason)
               reference1.child("car_owner_name").setValue(null);
               reference1.child("car_owner_phonenum").setValue(null);
               reference1.child("request_status").setValue(null);
               reference1.child("reason").setValue(null);
               reference1.child("request date").setValue(null);
               reference1.child("request time").setValue(null);
               reference1.child("boarding point").setValue(null);
               reference1.child("car owner email").setValue(null);
               reference1.child("boarding time").setValue(null)
                       .addOnSuccessListener(new OnSuccessListener<Void>() {
                           @Override
                           public void onSuccess(Void unused) {


                               ride_cancel_msg.setText("Your request cancelled!!");
                               ride_cancel_msg.setVisibility(View.VISIBLE);
                               ride_cancel_msg.setTextColor(Color.BLACK);
                               ride_cancel_msg.postDelayed(new Runnable() {
                                   @Override
                                   public void run() {
                                       ride_cancel_msg.setVisibility(View.INVISIBLE);
                                   }
                               },10000);
                               update_carpool_active_ride_table();
                               send_email_carpooler();
                           }
                       })
                       .addOnFailureListener(new OnFailureListener() {
                           @Override
                           public void onFailure(@NonNull Exception e) {

                           }
                       });

           }
/////////////////////////

           public void check_carpooler_table(){

               final DatabaseReference reference2 = FirebaseDatabase.getInstance("https://activerides-72ed2.firebaseio.com/").getReference().child(Owner_Phone).child(GlobalVariable.login_phone);

               reference2.addListenerForSingleValueEvent(new ValueEventListener() {
                   @Override
                   public void onDataChange(@NonNull DataSnapshot snapshot) {
                       if(snapshot.exists())
                       {
                           get_child_num();

                       }
                       else{
                           ride_cancel_msg.setText("This ride is closed by Carpooler.Please close this ride!!");
                           ride_cancel_msg.setVisibility(View.VISIBLE);
                           ride_cancel_msg.setTextColor(Color.BLACK);
                           ride_cancel_msg.postDelayed(new Runnable() {
                               @Override
                               public void run() {
                                   ride_cancel_msg.setVisibility(View.INVISIBLE);
                               }
                           },10000);
                       }
                   }

                   @Override
                   public void onCancelled(@NonNull DatabaseError error) {

                   }
               });


           }

//////////////////////

           public void update_carpool_active_ride_table()
           {
               final DatabaseReference reference3 = FirebaseDatabase.getInstance("https://activerides-72ed2.firebaseio.com/").getReference().child(Owner_Phone).child(GlobalVariable.login_phone);


               reference3.child("status").setValue("Cancelled by requestor");
               reference3.child("reason").setValue(Sreason)
                       .addOnSuccessListener(new OnSuccessListener<Void>() {
                           @Override
                           public void onSuccess(Void unused) {
                               checknumseats();

                           }
                       })
                       .addOnFailureListener(new OnFailureListener() {
                           @Override
                           public void onFailure(@NonNull Exception e) {

                           }
                       });
           }
///////////////////////////////

          public void checknumseats() {
               final DatabaseReference databaseReference2 = FirebaseDatabase.getInstance("https://ridedetailsdb.firebaseio.com/").getReference().child(Owner_Phone);
              databaseReference2.addListenerForSingleValueEvent(new ValueEventListener() {
                   @Override
                   public void onDataChange(@NonNull DataSnapshot snapshot) {
                       if (snapshot.exists()) {
                        num_of_seats = snapshot.child("seats available").getValue().toString();
                         max_num_of_seats = snapshot.child("maximum seats").getValue().toString();
                          System.out.println("Total_nm_seats1" + num_of_seats);
                         numseatschange();
                      }
                 }

                   @Override
                  public void onCancelled(@NonNull DatabaseError error) {

                  }
              });
           }

           //////////////////////
          public void numseatschange() {
             System.out.println("Total_nm_seats2" + num_of_seats);
              Total_num_seats = Integer.valueOf(num_of_seats);
              Total_max_num_seats = Integer.valueOf(max_num_of_seats);
               if (Total_num_seats >= 0) {
                   if (Total_num_seats < Total_max_num_seats) {
                       Total_num_seats = Total_num_seats + 1;
                       String STotal_num_seats = String.valueOf(Total_num_seats);
                       final DatabaseReference databaseReference = FirebaseDatabase.getInstance("https://ridedetailsdb.firebaseio.com/").getReference().child(Owner_Phone);

                       databaseReference.child("seats available").setValue(STotal_num_seats)
                               .addOnSuccessListener(new OnSuccessListener<Void>() {
                                   @Override
                                   public void onSuccess(Void unused) {

                                   }
                               })
                               .addOnFailureListener(new OnFailureListener() {
                                   @Override
                                   public void onFailure(@NonNull Exception e) {

                                   }
                               });
                   }
               }
           }



      });

 }

    public void send_email_carpooler()
    {


        try {
            String stringSenderEmail = "fiscarpool210623@gmail.com";
            String stringReceiverEmail = Carpooler_email_id;
            String stringPasswordSenderEmail = "foaunfwnqmabwibh";

            String stringHost = "smtp.gmail.com";

            Properties properties = System.getProperties();

            properties.put("mail.smtp.host", stringHost);
            properties.put("mail.smtp.port", "465");
            properties.put("mail.smtp.ssl.enable", "true");
            properties.put("mail.smtp.auth", "true");

            javax.mail.Session session = Session.getInstance(properties, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(stringSenderEmail, stringPasswordSenderEmail);
                }
            });

            MimeMessage mimeMessage = new MimeMessage(session);
            mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(stringReceiverEmail));

            mimeMessage.setSubject("Subject: FIS Carpool App email");
            mimeMessage.setText(GlobalVariable.login_name+" cancelled ride request with below reason \n\n"+ Sreason);

            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Transport.send(mimeMessage);
                    } catch (MessagingException e) {
                        e.printStackTrace();
                    }
                }
            });
            thread.start();

        } catch (AddressException e) {
            e.printStackTrace();
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


}