package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.TimePicker;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;

import com.google.android.gms.tasks.OnCompleteListener;

import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.TaskExecutors;

import com.google.firebase.FirebaseApp;
import com.google.firebase.appcheck.FirebaseAppCheck;
import com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.text.ParseException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import android.widget.Toast;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.google.firebase.FirebaseException;



public class MainActivity extends AppCompatActivity {

    private EditText Phonenumber;
    private TextView Msgbox, Starttimedb,Startdatedb;
    private int intLayout = 1;

    private EditText Currentdblocation;
    private EditText routedb;
    private EditText noseatsdb;
    private EditText Carnumdb;

    private EditText update_current_loc, update_route, update_seats, update_start_time, update_car_num;
    private TextView Maintext;
    private TextView Upassword;
    public String Mobilenum;
    public String Userphone;

    public String Sseatsdb,selectedDate;
    public String Sstrttimedb;
    public String Sroutedb,update_tab_start_date;
    public String Scurrentloc, final_tab_curr_loc, final_tab_route, final_tab_seat, final_tab_start_time, final_tab_car_num;
    public String Snamedb,ride_tab_start_loc,ride_tab_start_time,ride_tab_num_seats,Carpooler_email_id,ride_tab_start_date;
    public String Scarnum, getName_close, getPhonenum_close, getRequeststaus_close, getReqcancel_close, getReqdate_close, getReqtime_close, getBoardingpoint_close, getBoardingtime_close;


    private EditText password1;
    private EditText password2,Mobile_otp;
    private TextView cmsgfield;
    private TextView Changeloc;
    private TextView Offerridemsg;
    private static int Msg_timer = 1000;
    public long maxid = 0;
    public int t2hour, t2minute;
    public String Maxid = "1", Eligible_User = "N";


    private FirebaseAuth mAuth;
    private String verificationId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {



//        FirebaseApp.initializeApp(/*context=*/ this);
//        FirebaseAppCheck firebaseAppCheck = FirebaseAppCheck.getInstance();
//        firebaseAppCheck.installAppCheckProviderFactory(
//                PlayIntegrityAppCheckProviderFactory.getInstance());

        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_detail);



        loginoption();


    }
    public void onBackPressed(){
        if (intLayout== 1)
        {
            new AlertDialog.Builder(this)
                    .setMessage("Are you sure you want to close app?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();
                        }
                    })
                    .setNegativeButton("No",null)
                    .show();
        }
        if (intLayout== 2)
        {
            intLayout=1;
            setContentView(R.layout.user_detail);
            loginoption();
        }
        if (intLayout== 3)
        {
            intLayout=2;
            setContentView(R.layout.verifyphonenum);
            verifyphone();
        }
        if (intLayout== 4)
        {
            new AlertDialog.Builder(this)
                    .setMessage("Are you sure you want to exit?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            finish();
                        }
                    })
                    .setNegativeButton("No",null)
                    .show();

            // //////         intLayout=1;
            //          setContentView(R.layout.user_detail);
            //          loginoption();
        }
        if (intLayout== 5)
        {
            intLayout=4;
            setContentView(R.layout.category_option_offer_requestor);
            choose_offerer_rider(GlobalVariable.login_name);
        }
        if (intLayout== 6)
        {
            intLayout=4;
            setContentView(R.layout.category_option_offer_requestor);
            choose_offerer_rider(GlobalVariable.login_name);
        }
        if (intLayout== 7)
        {
            intLayout=5;
            setContentView(R.layout.activity_main_offer);
            activity_offerpoolscreen();
        }
        if (intLayout== 8)
        {
            intLayout=5;
            setContentView(R.layout.activity_main_offer);
            activity_offerpoolscreen();
        }
        if (intLayout== 9)
        {
            intLayout=6;
            setContentView(R.layout.activity_main_requestor);
            activity_ride_requestor();
        }
        if (intLayout== 14)
        {
            intLayout=6;
            setContentView(R.layout.activity_main_requestor);
            activity_ride_requestor();
        }
        if (intLayout== 15)
        {
            intLayout=6;
            setContentView(R.layout.activity_main_requestor);
            activity_ride_requestor();
        }

        if (intLayout== 12)
        {

            setContentView(R.layout.activity_main_offer);
            activity_offerpoolscreen();
        }

        if (intLayout== 13)
        {

            setContentView(R.layout.activity_main_offer);
            activity_offerpoolscreen();
        }



    }

    ///below code is to choose whether offer ride or search ride by user after successful login
    public void choose_offerer_rider(String username1) {


        Maintext = (TextView) findViewById(R.id.maintextid);
        Maintext.setText("Welcome " + username1 );
////////////////////////////////////////////




///////////////////////////////////////////////////////////////




       Button Uride_offer = (Button) findViewById(R.id.uride_offerid);
        Uride_offer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                setContentView(R.layout.activity_main_offer);
//                setContentView(R.layout.update_ride_details_by_offer);
                activity_offerpoolscreen();
            }
        });

        Button Uride_requestor = (Button) findViewById(R.id.uride_findid);
        Uride_requestor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                setContentView(R.layout.activity_main_requestor);
                activity_ride_requestor();
            }
        });
    }



    public void activity_offerpoolscreen(){

        intLayout = 5;
        TextView elbutton = (TextView) findViewById(R.id.elbuttonid);
        elbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intLayout=7;
                setContentView(R.layout.offer_ride);
                //               setContentView(R.layout.update_ride_details_by_offer);
                offerpoolscreen();
            }
        });

        TextView incoming_req = (TextView) findViewById(R.id.incoming_requests);
        incoming_req.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intLayout=8;
                setContentView(R.layout.request_check_by_ride_offer);
                check_request();
            }
        });

        TextView offer_history = (TextView) findViewById(R.id.ridegivenid);
        offer_history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intLayout=8;
                setContentView(R.layout.ride_offerer_history);
                ride_offerer_history();
            }
        });

        TextView Offer_my_rides = (TextView) findViewById(R.id.offer_my_rides);
        Offer_my_rides.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intLayout=11;
                setContentView(R.layout.loading_msg_my_rides_offerer);

                offerer_my_rides();
            }
        });
    }

    public void activity_ride_requestor(){
        intLayout = 6;
        TextView vlbutton = (TextView) findViewById(R.id.vlbuttonid);
        vlbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intLayout=9;
                setContentView(R.layout.findpoolrecycle);
                findpoolscreen();
            }
        });

        TextView reqbyme = (TextView) findViewById(R.id.homereqme);
        reqbyme.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intLayout=14;
                setContentView(R.layout.ridesreqrecycle);
                ridesrequested();
            }
        });

       TextView req_history = (TextView) findViewById(R.id.req_ride_history);
        req_history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intLayout=15;
                setContentView(R.layout.ride_requestor_history_recycle);
                ride_requested_history();
            }
        });


    }

    public void offerpoolscreen() {
        Currentdblocation = (EditText) findViewById(R.id.locdbid);
        routedb = (EditText) findViewById(R.id.offerpldbid);
        noseatsdb = (EditText) findViewById(R.id.numseatupid);
        Starttimedb = (TextView) findViewById(R.id.starttimedbid);
         Startdatedb = (TextView) findViewById(R.id.startdatedbid);
        Carnumdb = (EditText) findViewById(R.id.carnumdbid);
        EditText UserName=(EditText) findViewById(R.id.carnumdbid);

 //      Calendar calendar = Calendar.getInstance();
//       final String currentDate = DateFormat.getDateInstance().format(calendar.getTime());
//        Startdatedb.setText(currentDate);
        final DatabaseReference reference = FirebaseDatabase.getInstance("https://car-pool-userdb.firebaseio.com/").getReference().child(Userphone);

// ** Below code is to get current location and route fro user table
        reference.addValueEventListener(new ValueEventListener() {
            @Override

            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    Eligible_User="Y";
                    Scurrentloc =snapshot.child("location").getValue().toString();
                    Sroutedb =snapshot.child("route").getValue().toString();
                    Snamedb =snapshot.child("name").getValue().toString();

                    Currentdblocation.setText( Scurrentloc);
                    routedb.setText(Sroutedb);
                    Sseatsdb =snapshot.child("number_of_seats").getValue().toString();
                    noseatsdb.setText(Sseatsdb);
                    Sstrttimedb =snapshot.child("start_time").getValue().toString();
                    Starttimedb.setText(Sstrttimedb);
                    Scarnum =snapshot.child("car_regn_number").getValue().toString();
                    Carnumdb.setText(Scarnum);
                    Carpooler_email_id =snapshot.child("email_id").getValue().toString();



                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
//  Code ending here for populating location and route from User table
// Below  code is to add travel details into route table if the person offers an ride.

        update_ride_table();

    }

    public void update_ride_table()
    {

        Offerridemsg = (TextView) findViewById(R.id.offerrdemsgid);
        Button offerrbtn = (Button) findViewById(R.id.offridebt1);
        Starttimedb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("Time button clicked");
                TimePickerDialog timePickerDialog=new TimePickerDialog(MainActivity.this, android.R.style.Theme_Holo_Light_Dialog_MinWidth,
                        new TimePickerDialog.OnTimeSetListener() {


                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                System.out.println("Inside Ontime set");
                                t2hour=hourOfDay;
                                t2minute=minute;
                                String time=t2hour+":"+t2minute;
                                System.out.println("time:"+time);
                                System.out.println("t2hour"+t2hour);
                                System.out.println("t2minute"+t2minute);
                                SimpleDateFormat f24Hours=new SimpleDateFormat(
                                        "HH:mm"
                                );
                                try{
                                    Date date=f24Hours.parse(time);
                                    SimpleDateFormat f12Hours= new SimpleDateFormat(
                                            "hh:mm aa"
                                    );
                                    Starttimedb.setText(f12Hours.format(date));
                                    System.out.println("Boarding time2"+Starttimedb);
                                } catch (ParseException e){
                                    e.printStackTrace();
                                    System.out.println("Inside catch ");
                                }


                            }
                        },12,0,false
                );
                timePickerDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                timePickerDialog.updateTime(t2hour,t2minute);
                timePickerDialog.show();
            }


        });
        Startdatedb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get the current date
                Calendar currentDate = Calendar.getInstance();
                int year = currentDate.get(Calendar.YEAR);
                int month = currentDate.get(Calendar.MONTH);
                int day = currentDate.get(Calendar.DAY_OF_MONTH);


                // Create a DatePickerDialog
                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                                // Display the selected date
                                selectedDate = dayOfMonth + "/" + (monthOfYear + 1) + "/" + year;
                                System.out.println("selected date"+ selectedDate);
                                Startdatedb.setText(selectedDate);
                            }
                        }, year, month, day);

                // Show the DatePickerDialog
                datePickerDialog.show();
            }
        });

        offerrbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Currentdblocation = (EditText) findViewById(R.id.locdbid);
                routedb = (EditText) findViewById(R.id.offerpldbid);
                noseatsdb = (EditText) findViewById(R.id.numseatupid);
                Starttimedb = (TextView) findViewById(R.id.starttimedbid);
                Startdatedb = (TextView) findViewById(R.id.startdatedbid);
               Calendar calendar = Calendar.getInstance();
 //               final String currentDate = DateFormat.getDateInstance().format(calendar.getTime());

                LocalDate currentDate = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    currentDate = LocalDate.now();
                }
                DateTimeFormatter formatter = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
                }
                String formattedDate = null;
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    formattedDate = currentDate.format(formatter);
                }
                System.out.println("Current date_APK: " + formattedDate);


                System.out.println("Current date:"+ currentDate);
 //               Startdatedb.setText(currentDate);
                Carnumdb = (EditText) findViewById(R.id.carnumdbid);
                final String update_tab_current_loc = Currentdblocation.getText().toString().trim();
                final String update_tab_route = routedb.getText().toString().trim();
                final String update_tab_seats = noseatsdb.getText().toString().trim();
                final String update_tab_start_time = Starttimedb.getText().toString().trim();
                 update_tab_start_date = Startdatedb.getText().toString().trim();
                final String update_tab_car_num = Carnumdb.getText().toString().trim();
                if(update_tab_current_loc.equals(Scurrentloc))
                {
                    final_tab_curr_loc=Scurrentloc;

                }
                else {
                    final_tab_curr_loc=update_tab_current_loc;
                }
                if(update_tab_route.equals(Sroutedb))
                {
                    final_tab_route=Sroutedb;

                }
                else {
                    final_tab_route=update_tab_route;
                }
                if(update_tab_seats.equals(Sseatsdb))
                {
                    final_tab_seat=Sseatsdb;

                }
                else {
                    final_tab_seat=update_tab_seats;
                }
                if(update_tab_start_time.equals(Sstrttimedb))
                {
                    final_tab_start_time=Sstrttimedb;

                }
                else {
                    final_tab_start_time=update_tab_start_time;
                }

                if(update_tab_car_num.equals(Scarnum))
                {
                    final_tab_car_num=Scarnum;

                }
                else {
                    final_tab_car_num=update_tab_car_num;
                }
                if(Eligible_User.equals("Y")){
                    final DatabaseReference reference3 = FirebaseDatabase.getInstance("https://ridedetailsdb.firebaseio.com/").getReference().child(Userphone);

                      reference3.addListenerForSingleValueEvent(new ValueEventListener() {
                          @Override
                          public void onDataChange(@NonNull DataSnapshot snapshot) {
                              if (snapshot.exists()) {
                                  System.out.println("Checking rife table");

                                  ride_tab_start_loc = snapshot.child("start_loc").getValue().toString();
                                  ride_tab_start_time = snapshot.child("start time").getValue().toString();
                                  ride_tab_num_seats = snapshot.child("seats available").getValue().toString();
                                  ride_tab_start_date = snapshot.child("start date").getValue().toString();

                                  System.out.println("ride_start_loc:"+ride_tab_start_loc);
                                  System.out.println("ride_start_time:"+  ride_tab_start_time);
                                  System.out.println("ride_num_seats:"+ride_tab_num_seats);
                                  System.out.println("fin_ride_start_loc:"+final_tab_curr_loc);
                                  System.out.println("fin_ride_start_time:"+  final_tab_start_time);
                                  System.out.println("fin_ride_num_seats:"+final_tab_seat);
                                  if (ride_tab_start_loc.equals(final_tab_curr_loc)) {
                                      if (ride_tab_start_time.equals(final_tab_start_time)) {
                                          if (ride_tab_start_date.equals(update_tab_start_date)) {
                                              if (ride_tab_num_seats.equals(final_tab_seat)) {
                                                  Offerridemsg.setText("You have offered a ride already");
                                                  Offerridemsg.setVisibility(View.VISIBLE);
                                                  Offerridemsg.setTextColor(Color.RED);
                                                  Offerridemsg.postDelayed(new Runnable() {
                                                      @Override
                                                      public void run() {
                                                          Offerridemsg.setVisibility(View.INVISIBLE);
                                                      }
                                                  }, 10000);
                                              } else {
                                                  update_ride_table_info();
                                              }
                                          }
                                          else{
                                                  update_ride_table_info();
                                              }
                                          }

                                      else{
                                          update_ride_table_info();
                                      }
                                  }
                                  else{
                                      update_ride_table_info();
                                  }

                              } else {
                                  update_ride_table_info();
                              }


                          }

                          @Override
                          public void onCancelled(@NonNull DatabaseError error) {

                          }
                      });





                }

                else{
                    Offerridemsg.setText("You are not Eligible to Carpool!!");
                    Offerridemsg.setVisibility(View.VISIBLE);
                    Offerridemsg.setTextColor(Color.BLACK);
                    Offerridemsg.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Offerridemsg.setVisibility(View.INVISIBLE);
                        }
                    },10000);
                }
            }
        });
    }

public void update_ride_table_info()
{

    final DatabaseReference reference4 = FirebaseDatabase.getInstance("https://ridedetailsdb.firebaseio.com/").getReference().child(Userphone);

    reference4.child("Phonenum").setValue(Userphone);
    reference4.child("name").setValue(GlobalVariable.login_name);
    reference4.child("start_loc").setValue(final_tab_curr_loc);
    reference4.child("route").setValue(final_tab_route);
    reference4.child("start time").setValue(final_tab_start_time);
    reference4.child("seats available").setValue(final_tab_seat);
    reference4.child("maximum seats").setValue(final_tab_seat);
    reference4.child("email id").setValue(Carpooler_email_id);
    reference4.child("start date").setValue(update_tab_start_date);
    System.out.println("Inside Offer pool_Seats: " + Sseatsdb);
    GlobalVariable.num_of_seats=Sseatsdb;
    reference4.child("car regn num").setValue(final_tab_car_num);
    reference4.child("ready to offer ride").setValue("Y")
            .addOnSuccessListener(new OnSuccessListener<Void>() {
                @Override
                public void onSuccess(Void unused) {
                    Offerridemsg.setText("Thank you.We will show your details to ride requestor!!");
                    Offerridemsg.setVisibility(View.VISIBLE);
                    Offerridemsg.setTextColor(Color.BLACK);
                    Offerridemsg.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            Offerridemsg.setVisibility(View.INVISIBLE);
                        }
                    },10000);
                }
            })
            .addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {

                }
            });
}

    ////////////////////////////////////
    /// below code is to check incoming ride request by owner of the car

    public void check_request(){

        System.out.println("Test: Inside check_request_by_offerer");
        final DatabaseReference databaseReference=FirebaseDatabase.getInstance("https://activerides-72ed2.firebaseio.com/").getReference().child(Userphone);
        final List<MyItems1> myItemsList1=new ArrayList<>();
        final RecyclerView recyclerView1=findViewById(R.id.requestcheckrecycle);

        recyclerView1.setHasFixedSize(true);
        recyclerView1.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                myItemsList1.clear();

                System.out.println("Test: Inside on data change");
                if(snapshot.getValue() == null){

                    System.out.println("There are no rides available");
                    setContentView(R.layout.no_incoming_request);
                }

                for(DataSnapshot users: snapshot.getChildren()){
                    System.out.println("Test: Inside for loop to get data");
                    if(users.hasChild("name") && users.hasChild("Phonenum") && users.hasChild("status") && users.hasChild("reason") && users.hasChild("request date") && users.hasChild("request time") && users.hasChild("boarding point") && users.hasChild("boarding time") && users.hasChild("requestor email") ){
                        System.out.println("Test: Inside if condition to get data");

                        final String getName1=users.child("name").getValue(String.class);
                        final String getPhonenum1=users.child("Phonenum").getValue(String.class);
                        final String getRequeststaus1=users.child("status").getValue(String.class);
                        final String getReqcancel1=users.child("reason").getValue(String.class);
                        final String getReqdate1=users.child("request date").getValue(String.class);
                        final String getReqtime1=users.child("request time").getValue(String.class);
                        final String getBoardingpoint1=users.child("boarding point").getValue(String.class);
                        final String getBoardingtime1=users.child("boarding time").getValue(String.class);
                        final String getReqemailid1=users.child("requestor email").getValue(String.class);
                        System.out.println("inside get func requestor email:"+getReqemailid1);

                        MyItems1 myItems1 = new MyItems1(getName1,getPhonenum1,getRequeststaus1,getReqcancel1,getReqdate1,getReqtime1,getBoardingpoint1,getBoardingtime1,getReqemailid1);
                        myItemsList1.add(myItems1);

                    }


                }
                recyclerView1.setAdapter(new MyAdapter1(myItemsList1,MainActivity.this));

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    public void findpoolscreen() {
        System.out.println("inside find pool_check_start");
        TextView Msgnorides=findViewById(R.id.Noridesavailable);
        final DatabaseReference databaseReference=FirebaseDatabase.getInstance("https://ridedetailsdb.firebaseio.com/").getReference();
        final List<MyItems> myItemsList=new ArrayList<>();
        final RecyclerView recyclerView=findViewById(R.id.findpoolrecycle);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                myItemsList.clear();
                System.out.println("inside find pool_check");
                System.out.println("snapshot"+ snapshot);
               if(snapshot.getValue() == null){

                  System.out.println("There are no rides available_in find pool page");
                  setContentView(R.layout.no_available_rides);
                              }
                for(DataSnapshot users: snapshot.getChildren()){

                    System.out.println("users:"+users);
                    if(users.hasChild("name") && users.hasChild("Phonenum") && users.hasChild("start_loc") && users.hasChild("route") && users.hasChild("seats available") && users.hasChild("car regn num") && users.hasChild("email id") && users.hasChild("start date")){

                        final String getName=users.child("name").getValue(String.class);
                        final String getPhonenum=users.child("Phonenum").getValue(String.class);
                        final String getStartloc=users.child("start_loc").getValue(String.class);
                        final String getRoute=users.child("route").getValue(String.class);
                        final String getSeats=users.child("seats available").getValue(String.class);

                        final String getCarnum=users.child("car regn num").getValue(String.class);
                        final String getStarttime=users.child("start time").getValue(String.class);
                        final String getEmailid=users.child("email id").getValue(String.class);
                        final String getTraveldate=users.child("start date").getValue(String.class);
                        int intseat = Integer.valueOf(getSeats);
                        System.out.println("num of seats: " + intseat);
                        System.out.println("car num: " + getCarnum);

                        System.out.println("num of seats1: " + getSeats);

                        MyItems myItems = new MyItems(getName, getPhonenum, getStartloc, getRoute, getSeats,getCarnum,getStarttime,getEmailid,getTraveldate);
                        myItemsList.add(myItems);

                    }
                    else{
                        System.out.println("proper fields are not found in find pool page");
                    }


                }
                recyclerView.setAdapter(new MyAdapter(myItemsList,MainActivity.this));





            }



            @Override
            public void onCancelled(@NonNull DatabaseError error) {


            }

        });




    }
    ////// below code is to check list of rides requested and their  status
    public void ridesrequested() {

        final DatabaseReference databaseReference=FirebaseDatabase.getInstance("https://car-pool-accept-reject-pending.firebaseio.com/").getReference().child(GlobalVariable.login_phone);
        final List<MyItems2> myItemsList2=new ArrayList<>();
        final RecyclerView recyclerView2=findViewById(R.id.riderequeststatus_recycle);

        recyclerView2.setHasFixedSize(true);
        recyclerView2.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                myItemsList2.clear();
                if(snapshot.getValue() == null){

                    System.out.println("There are no rides available");
                    setContentView(R.layout.no_ride_request_sent);

                }
                for(DataSnapshot users: snapshot.getChildren()){
                    if(users.hasChild("car_owner_name") && users.hasChild("car_owner_phonenum") && users.hasChild("request_status") && users.hasChild("reason") && users.hasChild("request date") && users.hasChild("request time") && users.hasChild("car owner email")){
                        final String getName2=users.child("car_owner_name").getValue(String.class);
                        final String getPhonenum2=users.child("car_owner_phonenum").getValue(String.class);
                        final String getReqstatus2=users.child("request_status").getValue(String.class);
                        final String getReqcanreason2=users.child("reason").getValue(String.class);
                        final String getReqdate2=users.child("request date").getValue(String.class);
                        final String getReqtime2=users.child("request time").getValue(String.class);
                        final String getCarpooleremail2=users.child("car owner email").getValue(String.class);
                        MyItems2 myItems2 = new MyItems2(getName2,getPhonenum2,getReqstatus2,getReqcanreason2,getReqdate2,getReqtime2,getCarpooleremail2);
                        myItemsList2.add(myItems2);

                    }
                    //                 else{
                    //                       setContentView(R.layout.no_ride_request_sent);
                    //                   }

                }
                recyclerView2.setAdapter(new MyAdapter2(myItemsList2,MainActivity.this));

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }
    // above code is to find rides requested by user and check status//

    public void ride_requested_history() {

        final DatabaseReference databaseReference=FirebaseDatabase.getInstance("https://car-pool-ride-taken-history.firebaseio.com/").getReference().child(GlobalVariable.login_phone);
        final List<MyItems3> myItemsList3=new ArrayList<>();
        final RecyclerView recyclerView3=findViewById(R.id.ride_requestor_history_recycle);

        recyclerView3.setHasFixedSize(true);
        recyclerView3.setLayoutManager(new LinearLayoutManager(MainActivity.this));


        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                myItemsList3.clear();
                               if(snapshot.getValue() == null){

                              System.out.println("There are no rides available");
                                  setContentView(R.layout.no_ride_history);
             }
                for(DataSnapshot users: snapshot.getChildren()){
                    System.out.println("users:"+users);
                    if(users.hasChild("owner_name") && users.hasChild("request_date") && users.hasChild("request_cancel_reason") && users.hasChild("request_time") && users.hasChild("request_status")){

                        System.out.println("History child found");
                        final String getName3=users.child("owner_name").getValue(String.class);
                        final String getDate3=users.child("request_date").getValue(String.class);
                        final String getReqcanreason3=users.child("request_cancel_reason").getValue(String.class);
                        final String getReqstatus3=users.child("request_status").getValue(String.class);
                        final String getReqtime3=users.child("request_time").getValue(String.class);
                        System.out.println("getName:"+getName3);
                        System.out.println("getdate:"+getDate3);
                        System.out.println("getreason:"+getReqcanreason3);
                        System.out.println("getstatus:"+getReqstatus3);
                        MyItems3 myItems3 = new MyItems3(getName3,getReqstatus3,getReqcanreason3,getDate3,getReqtime3);
                        myItemsList3.add(myItems3);

                    }
                    else{
                        System.out.println("History child not found");
                    }

                }
                recyclerView3.setAdapter(new MyAdapter3(myItemsList3,MainActivity.this));

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }

    public void ride_offerer_history() {

        final DatabaseReference databaseReference=FirebaseDatabase.getInstance("https://car-pool-ride-given-history.firebaseio.com/").getReference().child(GlobalVariable.login_phone);
        final List<MyItems4> myItemsList4=new ArrayList<>();
        final RecyclerView recyclerView4=findViewById(R.id.ride_offerer_history_recycle);

        recyclerView4.setHasFixedSize(true);
        recyclerView4.setLayoutManager(new LinearLayoutManager(MainActivity.this));
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                myItemsList4.clear();
                          if(snapshot.getValue() == null){

                                System.out.println("There are no rides available");
                                setContentView(R.layout.no_ride_history);
                              }
                for(DataSnapshot users: snapshot.getChildren()){
                    System.out.println("users:"+users);
                    if(users.hasChild("requestor_name") && users.hasChild("request_date") && users.hasChild("request_cancel_reason") && users.hasChild("request_time") && users.hasChild("request_status")){

                        System.out.println("History child found");
                        final String getName4=users.child("requestor_name").getValue(String.class);
                        final String getDate4=users.child("request_date").getValue(String.class);
                        final String getReqcanreason4=users.child("request_cancel_reason").getValue(String.class);
                        final String getReqstatus4=users.child("request_status").getValue(String.class);
                        final String getReqtime4=users.child("request_time").getValue(String.class);

                        MyItems4 myItems4 = new MyItems4(getName4,getReqstatus4,getReqcanreason4,getDate4,getReqtime4);
                        myItemsList4.add(myItems4);

                    }
                    else{
                        System.out.println("History child not found");
                    }

                }
                recyclerView4.setAdapter(new MyAdapter4(myItemsList4,MainActivity.this));

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });



    }




    /** below code is for login with mobile number and password to offer ride and search ride
     *
     */



    public void offerer_my_rides() {


        System.out.println("inside my rides");


        final DatabaseReference reference1 = FirebaseDatabase.getInstance("https://ridedetailsdb.firebaseio.com/").getReference().child(Userphone);
         reference1.addListenerForSingleValueEvent(new ValueEventListener() {
             @Override
             public void onDataChange(@NonNull DataSnapshot snapshot) {
                 if(snapshot.exists())
                 {

                     intLayout=12;
                     setContentView(R.layout.offerer_my_rides_close_request);
                     TextView offer_Currentdblocation = (TextView) findViewById(R.id.off_myrides_locdbid);
                     TextView offer_routedb = (TextView) findViewById(R.id.off_myrides_offerpldbid);
                     TextView offer_noseatsdb = (TextView) findViewById(R.id.off_myrides_numseatupid);
                     TextView offer_Starttimedb = (TextView) findViewById(R.id.off_myrides_starttimedbid);
                     TextView offer_Carnumdb = (TextView) findViewById(R.id.off_myrides_carnumdbid);
                     TextView offer_Traveldate = (TextView) findViewById(R.id.off_myrides_traveldatedbid);

                     System.out.println("inside my rides");
                     String Offer_Scurrentloc =snapshot.child("start_loc").getValue().toString();
                     offer_Currentdblocation.setText(Offer_Scurrentloc);
                     String Offer_Sroutedb =snapshot.child("route").getValue().toString();
                     offer_routedb.setText(Offer_Sroutedb);
                     String Offer_Sseatsdb =snapshot.child("seats available").getValue().toString();
                     offer_noseatsdb.setText(Offer_Sseatsdb);
                     String  Offer_Sstrttimedb =snapshot.child("start time").getValue().toString();
                     offer_Starttimedb.setText(Offer_Sstrttimedb);
                     String  Offer_Scarnum =snapshot.child("car regn num").getValue().toString();
                     offer_Carnumdb.setText(Offer_Scarnum);
                     String  Offer_Straveldate =snapshot.child("start date").getValue().toString();
                     offer_Traveldate.setText(Offer_Straveldate);

                     close_my_rides_offerer();
                 }
                 else
                 {

                     intLayout=13;
                     setContentView(R.layout.no_rides_offered);
                 }
             }

             @Override
             public void onCancelled(@NonNull DatabaseError error) {

             }
         });


            }



// ** Below code is to get current location and route fro user table

//  Code ending here for populating location and route from User table
// Below  code is to add travel details into route table if the person offers an ride.



    public void close_my_rides_offerer()
    {

        System.out.println("inside closed rides");

        TextView Offer_my_rides_msg=(TextView) findViewById(R.id.off_myrides_offerrdemsgid);
        Button Offer_close_my_rides = (Button) findViewById(R.id.off_myrides_offridebt1);
        Offer_close_my_rides.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final DatabaseReference reference2 = FirebaseDatabase.getInstance("https://ridedetailsdb.firebaseio.com/").getReference().child(Userphone);

                reference2.child("name").setValue(null);
                reference2.child("Phonenum").setValue(null);

                reference2.child("ready to offer ride").setValue(null);
                reference2.child("route").setValue(null);
                reference2.child("seats available").setValue(null);
                reference2.child("maximum seats").setValue(null);
                reference2.child("start time").setValue(null);
                reference2.child("start_loc").setValue(null);
                reference2.child("email id").setValue(null);
                reference2.child("start date").setValue(null);
                reference2.child("car regn num").setValue(null)


                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                setContentView(R.layout.closing_ride_msg_by_offerer);
                                Offer_my_rides_msg.setText("Your ride is closed ");
                                Offer_my_rides_msg.setVisibility(View.VISIBLE);
                                Offer_my_rides_msg.setTextColor(Color.GREEN);
                                Offer_my_rides_msg.postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        Offer_my_rides_msg.setVisibility(View.INVISIBLE);
                                    }
                                },10000);


                            }
                        })
                        .addOnFailureListener(new OnFailureListener() {
                            @Override
                            public void onFailure(@NonNull Exception e) {

                            }
                        });


            }
        });
    }


    public void loginoption(){
        Msgbox = (TextView) findViewById(R.id.Msgboxid);
        Button lbutton = (Button) findViewById(R.id.lbuttonid);
        lbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Phonenumber = (EditText) findViewById(R.id.phoneid);
                Upassword = (EditText) findViewById(R.id.pwid);

                final String loginphone = Phonenumber.getText().toString().trim();
                Userphone = Phonenumber.getText().toString().trim();
                final String loginpw = Upassword.getText().toString().trim();
                System.out.println("input id1: " + Phonenumber);
                System.out.println("input id2: " + loginphone);

                if(loginphone.equals(""))
                {
                    Msgbox.setText("Phone number can't be empty !!");
                    Msgbox.setVisibility(View.VISIBLE);
                    Msgbox.setTextColor(Color.RED);
                }else
                if(loginphone.length() < 10){
                    Msgbox.setText("Phone number shoould be 10 digits");
                    Msgbox.setVisibility(View.VISIBLE);
                    Msgbox.setTextColor(Color.RED);

                }else
                if(loginpw.equals("")){
                    Msgbox.setText("Please Enter Password !!");
                    Msgbox.setVisibility(View.VISIBLE);
                    Msgbox.setTextColor(Color.RED);
                }
                else
                {
                    final DatabaseReference reference = FirebaseDatabase.getInstance("https://car-pool-3d063-default-rtdb.firebaseio.com/").getReference().child(loginphone);
                    Log.d("MyApp", "I am here 1");
                    reference.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if(dataSnapshot.exists()){
                                String Password = dataSnapshot.child("Password").getValue().toString();
                                final String Username = dataSnapshot.child("Name").getValue().toString();
                                String user_email_id = dataSnapshot.child("email_id").getValue().toString();

                                System.out.println("input id3: " + Password);
                                System.out.println("input id4: " + Upassword);
                                if(Password.equals(loginpw)) {
                                    Msgbox.setText("Welcome" +" "+ Username +"!!");
                                    Msgbox.setVisibility(View.VISIBLE);
                                    Msgbox.setTextColor(Color.BLUE);
                                    GlobalVariable.login_name=Username;
                                    GlobalVariable.login_phone=loginphone;
                                     GlobalVariable.login_email=user_email_id;
                                    intLayout=4;
                                    setContentView(R.layout.category_option_offer_requestor);
                                    choose_offerer_rider(Username);
//                                    categeroy(Username);
                                }
                                else {
                                    Msgbox.setText("Password is not correct!!");
                                    Msgbox.setVisibility(View.VISIBLE);
                                    Msgbox.setTextColor(Color.RED);
                                }

                            }
                            else{
                                Msgbox.setText("You are not Eligible!!");
                                Msgbox.setVisibility(View.VISIBLE);
                                Msgbox.setTextColor(Color.RED);

                            }

                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {
                            Msgbox.setText("Please try after sometime!!");
                            Msgbox.setVisibility(View.VISIBLE);

                        }
                    });
                }


            }
        });

       TextView frbutton = (TextView) findViewById(R.id.fchangepwid);
        frbutton.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            intLayout = 2;
                                            setContentView(R.layout.verifyphonenum);
                                            verifyphone();
                                        }
                                    }
        );
    }
    /** code is ending here
     *
     */
    /** below code is for verifying phone number before changing password
     *
     */
    public void verifyphone() {

        final TextView cmsgid;
        cmsgid = (TextView) findViewById(R.id.vpmsgboxid);
        Button pnext = (Button) findViewById(R.id.pnextid);
        pnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {
                EditText vphonenum;
                vphonenum = (EditText) findViewById(R.id.vphoneid);
                final String phonenumchange = vphonenum.getText().toString();
                Mobilenum = vphonenum.getText().toString();
                if (phonenumchange.equals("")) {
                    cmsgid.setText("Phone number can't be empty !!");
                    cmsgid.setVisibility(View.VISIBLE);
                    cmsgid.setTextColor(Color.RED);
                } else {
                    if (phonenumchange.length() < 10) {
                        cmsgid.setText("Phone number shoould be 10 digits !!");
                        cmsgid.setVisibility(View.VISIBLE);
                        cmsgid.setTextColor(Color.RED);
                    } else {
                        final DatabaseReference reference = FirebaseDatabase.getInstance("https://car-pool-3d063-default-rtdb.firebaseio.com/").getReference().child(phonenumchange);
                        reference.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if (snapshot.exists()) {
                                    Button nextbutton = (Button) findViewById(R.id.pnextid);
                                    nextbutton.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            intLayout=3;
                                           setContentView(R.layout.change_pw);
                                            changepassword();

//                                            setContentView(R.layout.verify_otp_screen);
//                                            verifyotp(phonenumchange);
                                        }
                                    });

                                } else {
                                    cmsgid.setText("OOPS!! You're not eligible!");
                                    cmsgid.setVisibility(View.VISIBLE);
                                    cmsgid.setTextColor(Color.RED);
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                cmsgid.setText("INVALID cancelled");
                                cmsgid.setVisibility(View.VISIBLE);
                            }
                        });
                    }
                }

            }
        });


    }
    /** code is ending here
     *
     */


    /** below code is for changing password by user
     *
     */
    public void changepassword(){
        TextView gobackfield= (TextView) findViewById(R.id.gobacklogid);
        cmsgfield = (TextView) findViewById(R.id.cmsgboxid);
        Button cbutton = (Button) findViewById(R.id.changepwid);

        cbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                password1 = (EditText) findViewById(R.id.epwid);
                final String spassword1 = password1.getText().toString().trim();
                password2 = (EditText) findViewById(R.id.repwid);
                final String spassword2 = password2.getText().toString().trim();
                System.out.println("input id5: " + password1);
                System.out.println("input id6: " + password2);
                System.out.println("input id7: " + spassword1);
                System.out.println("input id8: " + spassword2);

                if(spassword1.equals(""))
                {
                    cmsgfield.setText("Password cannot be empty");
                    cmsgfield.setTextColor(Color.RED);
                }
                else {
                    if(spassword2.equals("")){
                        cmsgfield.setText("Confirm Password cannot be empty");
                        cmsgfield.setTextColor(Color.RED);
                    }
                    else{
                        if(spassword1.equals(spassword2))
                        {
                            final DatabaseReference reference = FirebaseDatabase.getInstance("https://car-pool-3d063-default-rtdb.firebaseio.com/").getReference().child(Mobilenum);
                            reference.child("Password").setValue(spassword2)
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void unused) {
                                            cmsgfield.setText("Password Changed. Please Login again");
                                            cmsgfield.setTextColor(Color.BLUE);
                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            cmsgfield.setText("System Error. Please try after sometime.");
                                            cmsgfield.setTextColor(Color.RED);
                                        }
                                    });


                        }

                        else{
                            cmsgfield.setText("Confirm Password doesn't match with Password");
                            cmsgfield.setTextColor(Color.RED);
                        }
                    }
                }

            }
        });
        gobackfield.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setContentView(R.layout.user_detail);
                loginoption();
            }
        });
    }
/** code for changing password is ending here
 *
 */

///////////////below code is for verifying OTP//////////////////////////////






    public void verifyotp(String phoneNumber) {


        String phonenumber = "+" + "91" + phoneNumber;
        mAuth = FirebaseAuth.getInstance();
        Mobile_otp = findViewById(R.id.otp_id);
      Button  Verify_otp = findViewById(R.id.verify_otp_button);

//                String phonenumber = getIntent().getStringExtra("phonenumber");

        System.out.println("verify otp phonenumber: " + phonenumber);
        sendVerificationCode(phonenumber);

        Verify_otp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String code = Mobile_otp.getText().toString().trim();

                if (code.isEmpty() || code.length() < 6) {
                    Mobile_otp.setError("Enter code...");
                    Mobile_otp.requestFocus();
                    return;
                }
                else
                {
                    Toast.makeText(MainActivity.this, "Sit back and relax we are verifying OTP..", Toast.LENGTH_SHORT).show();
                }
                System.out.println("verify otp : " + code);
                verifyCode(code);


            }
        });

    }

    private void verifyCode(String code) {
        PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
        signInWithCredential(credential);
    }

    private void signInWithCredential(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(MainActivity.this, "OTP validated", Toast.LENGTH_LONG).show();

                            setContentView(R.layout.change_pw);
                            changepassword();

                        } else {
                            Toast.makeText(MainActivity.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });
    }

    private void sendVerificationCode(String number) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                number,
                120,
                TimeUnit.SECONDS,
                this,
                mCallBack
        );

    }

    private PhoneAuthProvider.OnVerificationStateChangedCallbacks
            mCallBack = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

        @Override
        public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
            super.onCodeSent(s, forceResendingToken);
            verificationId = s;
        }

        @Override
        public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
            String code = phoneAuthCredential.getSmsCode();
            if (code != null) {
                Mobile_otp.setText(code);
                verifyCode(code);
            }
        }

        @Override
        public void onVerificationFailed(FirebaseException e) {
            Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
    };









}