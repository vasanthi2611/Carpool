package com.example.myapplication;

public class MyItems2 {
    private String name,phonenumber,reqstatus,reqcanreason,reqdate,reqtime,carpooleremail;

    public MyItems2(String name, String phonenumber,String reqstatus,String reqcanreason,String reqdate,String reqtime,String carpooleremail) {
        this.name = name;
        this.phonenumber = phonenumber;
        this.reqstatus = reqstatus;
        this.reqdate = reqdate;
        this.reqtime = reqtime;
         this.reqcanreason=reqcanreason;
        this.carpooleremail=carpooleremail;

    }

    public String getName2() {
        return name;
    }

    public String getPhonenumber2() {
        return phonenumber;
    }

    public String getReqstatus2() {
        return reqstatus;
    }

    public String getReqcanreason2() {
        return reqcanreason;
    }

    public String getDate2() {
        return reqdate;
    }

    public String getTime2() {
        return reqtime;
    }

    public String getCarpooleremail2() {
        return carpooleremail;
    }

}
