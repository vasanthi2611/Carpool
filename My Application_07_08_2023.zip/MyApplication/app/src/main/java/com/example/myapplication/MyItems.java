package com.example.myapplication;

public class MyItems {
    private String name,phonenumber,startloc,seatsavailable,route,carnum,starttime,emailid,traveldate;

    public MyItems(String name, String phonenumber, String startloc,String route,String seatsavailable,String carnum,String starttime,String emailid,String traveldate) {
        this.name = name;
        this.phonenumber = phonenumber;
        this.startloc = startloc;
        this.seatsavailable = seatsavailable;
        this.route = route;
        this.carnum = carnum;
        this.starttime = starttime;
        this.emailid = emailid;
        this.traveldate = traveldate;
    }

    public String getName() {
        return name;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public String getStartloc() {
        return startloc;
    }

    public String getSeatsavailable() {
        return seatsavailable;
    }

    public String getRoute() {
        return route;
    }

    public String getCarnum() {
        return carnum;
    }
    public String getStarttime() {
        return starttime;
    }

    public String getEmailid() {
        return emailid;
    }
    public String getTraveldate() {
        return traveldate;
    }
}
