package com.example.myapplication;

public class MyItems4 {
    private String name,reqstatus,reqcanreason,reqdate,reqtime;

    public MyItems4(String name, String reqstatus,String reqcanreason,String reqdate,String reqtime) {
        this.name = name;

        this.reqstatus = reqstatus;
        this.reqdate = reqdate;
        this.reqtime = reqtime;
        this.reqcanreason=reqcanreason;


    }



    public String getName4() {
        return name;
    }



    public String getReqstatus4() {
        return reqstatus;
    }

    public String getReqcanreason4() {
        return reqcanreason;
    }

    public String getDate4() {
        return reqdate;
    }

    public String getTime4() {
        return reqtime;
    }

}
