package com.example.myapplication;

public class GlobalVariable {
    public static String login_phone, login_name,num_of_seats,login_email;
}
