package com.example.myapplication;

public class CarpoolerHistory {
    private String requestor_name,request_date,request_time,request_status,request_cancel_reason;

    public CarpoolerHistory() {
    }

    public String getRequestor_name() {
        return requestor_name;
    }

    public void setRequestor_name(String requestor_name) {
        this.requestor_name = requestor_name;
    }

    public String getRequest_date() {
        return request_date;
    }

    public void setRequest_date(String request_date) {
        this.request_date = request_date;
    }

    public String getRequest_time() {
        return request_time;
    }

    public void setRequest_time(String request_time) {
        this.request_time = request_time;
    }

    public String getRequest_status() {
        return request_status;
    }

    public void setRequest_status(String request_status) {
        this.request_status = request_status;
    }

    public String getRequest_cancel_reason() {
        return request_cancel_reason;
    }

    public void setRequest_cancel_reason(String request_cancel_reason) {
        this.request_cancel_reason = request_cancel_reason;
    }
}
