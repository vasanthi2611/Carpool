package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

///// this calss is to accept ride request by car owner and write status into active ride table and accept/reject table.
public class AcceptReject extends AppCompatActivity {

    private TextView name, phonenum,reqemailid;
    private String Sreqname, Sreqphone,Requestor_email_id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accept_reject);
        System.out.println("inside accept rej");

        name = findViewById(R.id.name4);
        phonenum = findViewById(R.id.phone4);
        reqemailid = findViewById(R.id.requestor_email_acceptrej);
        name.setText(getIntent().getStringExtra("name"));
        phonenum.setText(getIntent().getStringExtra("phonenum"));
        reqemailid.setText(getIntent().getStringExtra("reqemailid"));
        Sreqname = name.getText().toString().trim();
        Sreqphone = phonenum.getText().toString().trim();
        Requestor_email_id = reqemailid.getText().toString().trim();
        System.out.println("Requestor_email_id:"+Requestor_email_id);

        final DatabaseReference reference1 = FirebaseDatabase.getInstance("https://car-pool-accept-reject-pending.firebaseio.com/").getReference().child(Sreqphone).child(GlobalVariable.login_phone);
        reference1.child("request_status").setValue("Accepted")
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {

                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });

        final DatabaseReference reference2 = FirebaseDatabase.getInstance("https://activerides-72ed2.firebaseio.com/").getReference().child(GlobalVariable.login_phone).child(Sreqphone);
        reference2.child("status").setValue("Accepted")
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void unused) {
                    send_email_to_requestor();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                    }
                });


    }
    public void send_email_to_requestor(){

        try {
            String stringSenderEmail = "fiscarpool210623@gmail.com";
            String stringReceiverEmail = Requestor_email_id;
            String stringPasswordSenderEmail = "foaunfwnqmabwibh";

            String stringHost = "smtp.gmail.com";

            Properties properties = System.getProperties();

            properties.put("mail.smtp.host", stringHost);
            properties.put("mail.smtp.port", "465");
            properties.put("mail.smtp.ssl.enable", "true");
            properties.put("mail.smtp.auth", "true");

            javax.mail.Session session = Session.getInstance(properties, new Authenticator() {
                @Override
                protected PasswordAuthentication getPasswordAuthentication() {
                    return new PasswordAuthentication(stringSenderEmail, stringPasswordSenderEmail);
                }
            });

            MimeMessage mimeMessage = new MimeMessage(session);
            mimeMessage.addRecipient(Message.RecipientType.TO, new InternetAddress(stringReceiverEmail));

            mimeMessage.setSubject("Subject: FIS Carpool App email");
            mimeMessage.setText(GlobalVariable.login_name+" accepted your request");

            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Transport.send(mimeMessage);
                    } catch (MessagingException e) {
                        e.printStackTrace();
                    }
                }
            });
            thread.start();

        } catch (AddressException e) {
            e.printStackTrace();
        } catch (MessagingException e) {
            e.printStackTrace();
        }
    }

}



