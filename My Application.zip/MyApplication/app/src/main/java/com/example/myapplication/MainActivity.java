package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private EditText Phonenumber;
    private TextView Msgbox;

    private TextView Currentdblocation;
    private TextView Maintext;
    private TextView Upassword;
    public String Mobilenum;
    public String Userphone;
    private EditText password1;
    private EditText password2;
    private TextView cmsgfield;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.user_detail);
        loginoption();
    }

    /** below code is to choose whether offer ride or search ride by user after successful login
     *
     */
    public void categeroy(String username) {
        Maintext = (TextView) findViewById(R.id.maintextid);
        Maintext.setText("Hey" +" "+ username +" "+"!!");
        Button elbutton = (Button) findViewById(R.id.elbuttonid);
        elbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setContentView(R.layout.offer_ride);
                offerpoolscreen();
            }
        });

        Button vlbutton = (Button) findViewById(R.id.vlbuttonid);
        vlbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setContentView(R.layout.rider_screen);
                findpoolscreen();
            }
        });
    }

    /** code is ending here
     *
     */

    public void offerpoolscreen() {
        Currentdblocation = (TextView) findViewById(R.id.locdbid);
        final DatabaseReference reference = FirebaseDatabase.getInstance("https://car-pool-userdb.firebaseio.com/").getReference().child(Userphone);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
               if(snapshot.exists()){
                String Scurrentloc =snapshot.child("location").getValue().toString();
                   Currentdblocation.setText( Scurrentloc);
               }
               else
               {
                   Currentdblocation.setText( "Data is not exist");
               }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
    public void findpoolscreen() {

    }
    /** below code is for login with mobile number and password to offer ride and search ride
     *
     */
    public void loginoption(){
        Msgbox = (TextView) findViewById(R.id.Msgboxid);
        Button lbutton = (Button) findViewById(R.id.lbuttonid);
        lbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            Phonenumber = (EditText) findViewById(R.id.phoneid);
            Upassword = (EditText) findViewById(R.id.pwid);

            final String loginphone = Phonenumber.getText().toString().trim();
                Userphone = Phonenumber.getText().toString().trim();
            final String loginpw = Upassword.getText().toString().trim();
                System.out.println("input id1: " + Phonenumber);
                System.out.println("input id2: " + loginphone);

                if(loginphone.equals(""))
                {
                    Msgbox.setText("Phone number can't be empty !!");
                    Msgbox.setVisibility(View.VISIBLE);
                    Msgbox.setTextColor(Color.RED);
                }else
                    if(loginphone.length() < 10){
                        Msgbox.setText("Phone number shoould be 10 digits");
                        Msgbox.setVisibility(View.VISIBLE);
                        Msgbox.setTextColor(Color.RED);

                    }else
                        if(loginpw.equals("")){
                            Msgbox.setText("Please Enter Password !!");
                            Msgbox.setVisibility(View.VISIBLE);
                            Msgbox.setTextColor(Color.RED);
                        }
                        else
                        {
                            final DatabaseReference reference = FirebaseDatabase.getInstance("https://car-pool-3d063-default-rtdb.firebaseio.com/").getReference().child("Carpool").child(loginphone);
                            Log.d("MyApp", "I am here 1");
                            reference.addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    if(dataSnapshot.exists()){
                                        String Password = dataSnapshot.child("Password").getValue().toString();
                                        final String Username = dataSnapshot.child("Name").getValue().toString();
                                        System.out.println("input id3: " + Password);
                                        System.out.println("input id4: " + Upassword);
                                        if(Password.equals(loginpw)) {
                                            Msgbox.setText("Welcome" +" "+ Username +"!!");
                                            Msgbox.setVisibility(View.VISIBLE);
                                            Msgbox.setTextColor(Color.BLUE);
                                            setContentView(R.layout.activity_main);
                                            categeroy(Username);
                                        }
                                        else {
                                            Msgbox.setText("Password is not correct!!");
                                            Msgbox.setVisibility(View.VISIBLE);
                                            Msgbox.setTextColor(Color.RED);
                                        }

                                    }
                                    else{
                                        Msgbox.setText("You are not Eligible!!");
                                        Msgbox.setVisibility(View.VISIBLE);
                                        Msgbox.setTextColor(Color.RED);

                                    }

                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {
                                    Msgbox.setText("Please try after sometime!!");
                                    Msgbox.setVisibility(View.VISIBLE);

                                }
                            });
                        }


            }
        });

        Button frbutton = (Button) findViewById(R.id.fchangepwid);
        frbutton.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            setContentView(R.layout.verifyphonenum);
                                            verifyphone();
                                        }
                                    }
        );
    }
    /** code is ending here
     *
     */
    /** below code is for verifying phone number before changing password
     *
     */
    public void verifyphone() {

        final TextView cmsgid;
        cmsgid = (TextView) findViewById(R.id.vpmsgboxid);
        Button pnext = (Button) findViewById(R.id.pnextid);
        pnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View view) {
                EditText vphonenum;
                vphonenum = (EditText) findViewById(R.id.vphoneid);
                final String phonenumchange = vphonenum.getText().toString();
                Mobilenum = vphonenum.getText().toString();
                if (phonenumchange.equals("")) {
                    cmsgid.setText("Phone number can't be empty !!");
                    cmsgid.setVisibility(View.VISIBLE);
                    cmsgid.setTextColor(Color.RED);
                } else {
                    if (phonenumchange.length() < 10) {
                        cmsgid.setText("Phone number shoould be 10 digits !!");
                        cmsgid.setVisibility(View.VISIBLE);
                        cmsgid.setTextColor(Color.RED);
                    } else {
                        final DatabaseReference reference = FirebaseDatabase.getInstance("https://car-pool-3d063-default-rtdb.firebaseio.com/").getReference().child("Carpool").child(phonenumchange);
                        reference.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                if (snapshot.exists()) {
                                    Button nextbutton = (Button) findViewById(R.id.pnextid);
                                    nextbutton.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            setContentView(R.layout.change_pw);
                                            changepassword();
                                        }
                                    });

                                } else {
                                    cmsgid.setText("OOPS!! You're not eligible!");
                                    cmsgid.setVisibility(View.VISIBLE);
                                    cmsgid.setTextColor(Color.RED);
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {
                                cmsgid.setText("INVALID cancelled");
                                cmsgid.setVisibility(View.VISIBLE);
                            }
                        });
                    }
                }

            }
        });


    }
    /** code is ending here
     *
     */


    /** below code is for changing password by user
     *
     */
    public void changepassword(){
          TextView gobackfield= (TextView) findViewById(R.id.gobacklogid);
         cmsgfield = (TextView) findViewById(R.id.cmsgboxid);
        Button cbutton = (Button) findViewById(R.id.changepwid);

            cbutton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    password1 = (EditText) findViewById(R.id.epwid);
                    final String spassword1 = password1.getText().toString().trim();
                    password2 = (EditText) findViewById(R.id.repwid);
                    final String spassword2 = password2.getText().toString().trim();
                    System.out.println("input id5: " + password1);
                    System.out.println("input id6: " + password2);
                    System.out.println("input id7: " + spassword1);
                    System.out.println("input id8: " + spassword2);

                    if(spassword1.equals(""))
                    {
                        cmsgfield.setText("Password cannot be empty");
                        cmsgfield.setTextColor(Color.RED);
                    }
                    else {
                      if(spassword2.equals("")){
                          cmsgfield.setText("Confirm Password cannot be empty");
                          cmsgfield.setTextColor(Color.RED);
                      }
                      else{
                          if(spassword1.equals(spassword2))
                          {
                              final DatabaseReference reference = FirebaseDatabase.getInstance("https://car-pool-3d063-default-rtdb.firebaseio.com/").getReference().child("Carpool").child(Mobilenum);
                             reference.child("Password").setValue(spassword2)
                                     .addOnSuccessListener(new OnSuccessListener<Void>() {
                                         @Override
                                         public void onSuccess(Void unused) {
                                             cmsgfield.setText("Password Changed. Please Login again");
                                             cmsgfield.setTextColor(Color.GREEN);
                                         }
                                     })
                              .addOnFailureListener(new OnFailureListener() {
                                  @Override
                                  public void onFailure(@NonNull Exception e) {
                                      cmsgfield.setText("System Error. Please try after sometime.");
                                      cmsgfield.setTextColor(Color.RED);
                                  }
                              });


                          }

                          else{
                              cmsgfield.setText("Confirm Password doesn't match with Password");
                              cmsgfield.setTextColor(Color.RED);
                          }
                      }
                    }

                }
            });
       gobackfield.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
            setContentView(R.layout.user_detail);
            loginoption();
           }
       });
    }
/** code for changing password is ending here
 *
 */

}